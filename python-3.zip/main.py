'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
x="extraordinary"
print (x[5:13])
y="pneumonia"
print(y[4:9])
z="programming"
print(z[:-4])
a="establishment"
print(a[-4:-1])
b="pneumonoultramicroscopicsilicovolcanoconiosis"
print(b[-32:-20])
c="ya,bab=da,=d,adw=d"
print(c.split(","))
d=3
e=45.98
f="I bought {} pieces of cake for {} dollars."
print(f.format(d, e))
g=" da wsad "
print(g.strip())
h="hat"
print(h.replace("h","c"))
print(h.replace("h","m"))
i="boom shakalaka, yabadaba"
print(i.split(","))
x="yadgbwdads"
print(x.capitalize())