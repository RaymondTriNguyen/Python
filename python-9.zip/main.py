list1=["beans","jkwans","WDJKWLDNAL"]
list2=[1,2,3,4,5,6,7,8,8,9,0,0,8,65,4,6,7,5,5]
print(list1+list2)
for x in list2:
    list1.append(x)
print(list1)
list1=["beans","jkwans","WDJKWLDNAL"]
list1.extend(list2)
print(list1)
#tuples
tuple1=("apple","kiwi",2,78.6,67j,False)
print(tuple1)
print(len(tuple1))
tuple1=tuple(("pear",78,98.4,"kiwi",True,"pear"))
print(tuple1)
tuple2=("pear",78,98.4,"kiwi",True,"pear")
print(tuple2[2])
print(tuple2[1:3])
print(tuple2[-4:])
thistuple=("apple is a fruit")
if "eat" in thistuple:
    print("yes")
else:
    print("no")
tuplereal=tuple(("real","no",1,3413.43,341.43j))
print(tuplereal)
print(len(tuplereal))
print(type(tuplereal))
print(tuplereal[-3:])
if "real" in tuplereal:
    print("real")