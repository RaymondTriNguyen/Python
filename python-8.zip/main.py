#List Comprehension:
fruits=["apple","kiwi","pear"]
newlist=[]
for x in fruits:
    if "i" in x:
        newlist.append(x)
print(newlist)
fruits=["apple","kiwi","pear"]
newlist=[x for x in fruits if "e" in x]
print(newlist)
fruits=["apple","kiwi","pear"]
newlist=[x for x in fruits if x!="apple"]
print(newlist)
fruits=["apple","kiwi","pear"]
newlist=[x for x in fruits]
print(newlist)
newlist=[x for x in range(10)]
print(newlist)
newlist=[x for x in range(10) if x<=10]
print(newlist)
fruits=["apple","kiwi","pear"]
newlist=[x.upper() for x in fruits]
print(newlist)
#Sort List:
list1=["orange","apple","watermelon"]
list1.sort(reverse=True)
print(list1)
#Descending
list1=["orange","apple","watermelon"]
list1.sort(reverse=True)
print(list1)
list2=[23,87,56,98,22,12,1]
list2.sort(reverse=True)
print(list2)
list3=["umbrella","conditioner","parrot"]
list3.reverse()
print(list3)
number=["1","2","3","4","4","5","5","6","5","6","677","7","8","88","9"]

djwdjkadjskdjwkdjaksjdwkdjaksd=[]
for x in number:
    if "7" in x:
        djwdjkadjskdjwkdjaksjdwkdjaksd.append(x)
print(djwdjkadjskdjwkdjaksjdwkdjaksd)
newlist=[x for x in range(21)]
print(newlist)
something=["bob","WDJWKD","wijikada"]
something.sort()
print(something)
something=[5,4,6,8,4,8,7,4,8,7,48,7,4,8,7,48,56,26,543,57,49,67,37,8,48,56,488,49,780,9,59,487,]
something.sort(reverse=True)
print(something)
something=[5,4,6,8,4,8,7,4,8,7,48,7,4,8,7,48,56,26,543,57,49,67,37,8,48,56,488,49,780,9,59,487,]
something.reverse()
print(something)
#Copy Method;
list3=["umbrella","conditioner","parrot"]
list4=list3.copy()
print(list4)
#List Method
list3=["umbrella","conditioner","parrot"]
newlist=list(list3)
print(newlist)