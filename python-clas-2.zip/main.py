'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
x="Python"
y="is"
z="a"
w="snake"
x2="Python"
y2=" is"
z2=" a"
w2=" snake"
print(x,y,z,w)
print(x2+y2+z2+w2)
one=1
two=2.22
three=333j
x=y=z=1
print(x,y,z)
print(type(x))
numbers=["one","two","three"]
x,y,z=numbers
print(x,y,z)
b="Python is a popular programming language created by Guido Van Rossum in 1991."
print(b[49])
