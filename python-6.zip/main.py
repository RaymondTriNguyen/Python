'''
#list:
my_list=["monday","tuesday","wednesday"]
print(my_list)
my_list=["monday","tuesday","wednesday","monday"]
print(my_list)
#length:
my_list=["monday","tuesday","wednesday","wednesday","monday"]
print(len(my_list))
#type:
my_list=["monday","tuesday","wednesday","wednesday","monday"]
print(my_list)
print(type(my_list))
#list constructor
my_list=list(("apple", "orange"))
print(my_list)
my_list=[1,2,3,4,5,6,7,8,9,0,5,1345,6,256,7,36,8,356]
print(len(my_list))
print(type(my_list))
print(my_list[1])
print(my_list[-15])
my_list=["apple","kiwi","cherry"]
print(my_list)
my_list[1:2]=["pineapple", "watermelon"]
print(my_list)
#append method
my_list=["apple","kiwi","cherry"]
print(my_list)
my_list.append("pear")
print(my_list)
#insert
my_list=["apple","kiwi","cherry"]
print(my_list)
my_list.insert(1,"pear")
print(my_list)
'''
my_list=list(("raymond","kyler","brian","name","someone"))
print(my_list)
print(my_list[1:3])
my_list[1]="person"
print(my_list)
my_list.append("beans")
print(my_list)
my_list.insert(2,"beans")
print(my_list)