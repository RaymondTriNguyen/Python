#Extend List:
fruits=["apple","pear","kiwi"]
vegetable=["carrot","radish","lemon"]
fruits.extend(vegetable)
print(fruits)
#Iterables, Tuples, Sets, Dictionaries:
fruits=["apple","pear","kiwi"]
vegetable=("carrot","radish","lemon")
fruits.extend(vegetable)
print(fruits)
letters=['a','b','c']
numbers=[1,2,3]
letters.extend(numbers)
print(letters)
#pop method
fruits=["apple","pear","kiwi"]
fruits.pop(1)
print(fruits)
#clear
fruits=["apple","pear","kiwi"]
fruits.clear()
print(fruits)
#delete
fruits=["apple","pear","kiwi"]
#del fruits
print(fruits)
fruits=["apple","pear","kiwi"]
fruits.pop(2)
print(fruits)
fruits.clear()
print(fruits)
#Loop Lists:
fruits=["apple","pear","kiwi"]
for x in fruits:
    print(x)
fruits=["apple","pear","kiwi"]
for i in range(len(fruits)):
    print(fruits[i])
#While Loop:
fruits=["apple","pear","kiwi"]
i=0
while i<len(fruits):
    print(fruits[i])
    i=i+1
#Short-Hand For Loop:
fruits=["apple","pear","kiwi"]
[print(x) for x in fruits]
fruits=["apple","pear","kiwi"]
for i in range(len(fruits)):
    print(fruits[i])
fruits=["apple","pear","kiwi"]
i=0
while i<len(fruits):
    print(fruits[i])
    i=i+1
fruits=["apple","pear","kiwi"]
[print(x) for x in fruits]
numbers=[1,2,3,4,5,6,7,8,9,10]
i=0
while i<len(numbers):
    print(numbers[i])
    i=i+1
[print(x) for x in numbers]