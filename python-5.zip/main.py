'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
sentence="There are {} chicken mcnuggets."
x=10
print (sentence.format(x))
x="I am learning "
y="python strings."
print (x+y)
x="capatilize"
print(x.capitalize())
x='I\'m real the real the real the real orange.'
print(x)
x="the \t t"
print(x)
x="back \bspace"
print(x)
x="new \n line"
x=9
y=3
print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)
print(x**y)
print(x//y)
#Assignment Operators: (=, +=, -=, *=, /=, **=, //=, &=, >>==, <<=)
x=7
print(x)
x=7
x+=2
print(x)
x=7
x-=2
print(x)
x=7
x*=2
print(x)
x=7
x/=2
print(x)
x=7
x**=2
print(x)
x=7
x//=2
print(x)
x=7
x&=2
print(x)
x=7
x>>=2
print(x)
x=7
x<<=2
print(x)
x=7
y=2
print(x>y)
print(x<y)
print(x>=y)
print(x<=y)
print(x==y)
print(x!=y)
print(x>y and y<x)
print(x>y or y>x)
print(not(x>y and y>x))
x="This is a sentence"
print("sentence" in x)
print("minecraft" not in x)
print(x is "This is a sentence")
print(x is not "This is a burger")